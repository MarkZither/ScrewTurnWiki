Icons are from Tutorial9 - download more at:
http://www.tutorial9.net/resources/108-mono-icons-huge-set-of-minimal-icons/