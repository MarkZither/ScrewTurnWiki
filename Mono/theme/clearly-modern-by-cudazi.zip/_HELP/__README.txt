

Please open the index.html file with your browser.

You do not need to edit the assets folder but it must remain in the same folder as index.html to read the images/etc.

Thanks!