using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

// Between official releases, be sure to use the "(CVS)" version of the
// title to help differentiate between official releases and intermediate
// snapshots.

[assembly: AssemblyTitle("Anthem for ASP.NET 2.0")]
[assembly: AssemblyVersion("1.5.2.0")]
[assembly: AssemblyFileVersion("1.5.2.0")]
[assembly: TagPrefix("Anthem", "anthem")]

[assembly: ComVisible(false)]
[assembly: System.CLSCompliant(true)]
