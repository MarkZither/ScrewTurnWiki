﻿//    License: Microsoft Public License (Ms-PL) 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lucene.Net;
using Lucene.Net.Store;
using Microsoft.WindowsAzure.StorageClient;
using System.Diagnostics;
using System.Data.Services.Client;

namespace Lucene.Net.Store.Azure {

	/// <summary>
	/// Implements lock semantics on AzureDirectory via a table
	/// </summary>
	public class AzureTableLock : Lock {
		private string _lockFile;
		private AzureDirectory _azureDirectory;

		public AzureTableLock(string lockFile, AzureDirectory directory) {
			_lockFile = lockFile;
			_azureDirectory = directory;
		}

		#region Lock methods

		public override bool IsLocked() {
			return GetLockEntity() != null;
		}

		public override bool Obtain() {
			try {
				_azureDirectory.TableContext.AddObject(_azureDirectory.LockTableName, BuildLockEntity());
				_azureDirectory.TableContext.SaveChangesWithRetries();
				return true;
			}
			catch(DataServiceRequestException ex) {
				if(ex.Response.Any(r => r.StatusCode == (int)System.Net.HttpStatusCode.Conflict)) return false;
				throw;
			}
		}

		public override void Release() {
			LockEntity lockEntity = GetLockEntity();
			if(lockEntity == null) return;

			_azureDirectory.TableContext.DeleteObject(lockEntity);
			_azureDirectory.TableContext.SaveChangesWithRetries();
		}

		#endregion

		public override System.String ToString() {
			return "Lock@" + _lockFile;
		}

		#region Table Entity Management

		private LockEntity BuildLockEntity() {
			return new LockEntity() {
				PartitionKey = "Lock",
				RowKey = _lockFile
			};
		}

		private LockEntity GetLockEntity() {
			var query = (from e in _azureDirectory.TableContext.CreateQuery<LockEntity>(_azureDirectory.LockTableName).AsTableServiceQuery()
						 where e.PartitionKey.Equals(BuildLockEntity().PartitionKey) && e.RowKey.Equals(BuildLockEntity().RowKey)
						 select e).AsTableServiceQuery();
			return QueryHelper<LockEntity>.FirstOrDefault(query);
		}

		#endregion
	}

	public class LockEntity : TableServiceEntity {
		// PartitionKey = "Lock"
		// RowKey = _lockFile
	}
}
