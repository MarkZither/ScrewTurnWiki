Lucene.Net Snowball.Net README file

INTRODUCTION

This project provides pre-compiled version of the Snowball stemmers
together with classes integrating them with the Lucene search engine.

More documentation is provided in the 'docs' subdirectory.

For more information on Lucene.Net, see:
  http://incubator.apache.org/lucene.net/

For more information on Snowball, see:
  http://snowball.tartarus.org/

